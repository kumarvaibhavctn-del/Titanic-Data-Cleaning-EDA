# Titanic Data Cleaning and EDA (R)

This repository contains the R script for Task 1: data cleaning, preprocessing and preliminary exploratory data analysis.

## Dataset
Seaborn Titanic dataset (891 rows, 15 columns). Public CSV:
https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv

## Run
1. Install R and RStudio.
2. Open `titanic_data_cleaning_eda.R`.
3. Run the script. It installs the required packages if needed.
4. The script creates cleaned and encoded CSV files plus an outlier summary in the working directory.

## Methods
- Missing values: median imputation for `age`, mode imputation for `embarked`.
- Removed `deck` due to very high missingness; removed redundant `embark_town` and duplicate outcome label `alive`.
- Outliers: IQR rule; observations are flagged, not automatically deleted.
- Scaling: min-max normalization for age and fare.
- Encoding: `model.matrix()` dummy encoding for categorical predictors.
- EDA: summaries, frequency tables, grouped means, correlations and ggplot2 visualizations.

## Important
The report documents known baseline dataset characteristics. Run the R script in your own R environment to regenerate the exact outputs and figures before final submission.
