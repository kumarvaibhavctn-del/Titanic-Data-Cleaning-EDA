# Task 1: Data Cleaning, Preprocessing and EDA in R
# Dataset: Seaborn Titanic dataset (891 rows, 15 columns)
# Source: https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv

# 1. Setup
packages <- c("ggplot2", "dplyr", "tidyr", "corrplot")
new_packages <- packages[!(packages %in% installed.packages()[, "Package"])]
if (length(new_packages) > 0) install.packages(new_packages)
invisible(lapply(packages, library, character.only = TRUE))

# 2. Import data
url <- "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv"
titanic <- read.csv(url, stringsAsFactors = FALSE)
dim(titanic)       # Expected: 891 15
str(titanic)
summary(titanic)

# 3. Initial data-quality checks
colSums(is.na(titanic))
sapply(titanic, function(x) sum(is.na(x)))

# 4. Remove redundant / highly incomplete columns
# deck has 688 missing values (about 77.2%); imputation would be unreliable.
# embark_town duplicates the information in embarked, so retain embarked only.
clean <- titanic %>%
  select(-deck, -embark_town, -alive)

# 5. Handle missing values
# Age is numeric and skewed; median is less sensitive to extreme values than mean.
age_median <- median(clean$age, na.rm = TRUE)
clean$age[is.na(clean$age)] <- age_median

# Embarked is categorical; replace the two missing entries with its mode.
mode_value <- names(sort(table(clean$embarked), decreasing = TRUE))[1]
clean$embarked[is.na(clean$embarked)] <- mode_value

# Verify missing values after treatment
colSums(is.na(clean))

# 6. Convert variables to suitable types
clean$survived <- factor(clean$survived, levels = c(0, 1),
                         labels = c("No", "Yes"))
clean$pclass <- factor(clean$pclass, levels = c(1, 2, 3),
                       labels = c("First", "Second", "Third"))
clean$sex <- factor(clean$sex)
clean$embarked <- factor(clean$embarked)
clean$class <- factor(clean$class)
clean$who <- factor(clean$who)
clean$adult_male <- as.logical(clean$adult_male)
clean$alone <- as.logical(clean$alone)

# 7. Outlier detection using IQR rule (flag only; do not delete automatically)
numeric_vars <- c("age", "fare", "sibsp", "parch")
outlier_summary <- data.frame(
  variable = numeric_vars,
  lower_bound = NA_real_,
  upper_bound = NA_real_,
  outlier_count = NA_integer_
)
for (i in seq_along(numeric_vars)) {
  x <- clean[[numeric_vars[i]]]
  q1 <- quantile(x, 0.25, na.rm = TRUE)
  q3 <- quantile(x, 0.75, na.rm = TRUE)
  iqr_value <- IQR(x, na.rm = TRUE)
  lower <- q1 - 1.5 * iqr_value
  upper <- q3 + 1.5 * iqr_value
  outlier_summary$lower_bound[i] <- lower
  outlier_summary$upper_bound[i] <- upper
  outlier_summary$outlier_count[i] <- sum(x < lower | x > upper, na.rm = TRUE)
}
print(outlier_summary)

# 8. Normalization: min-max scale continuous variables for later modelling.
# Keep original variables and create *_scaled columns for transparency.
scale_minmax <- function(x) {
  if (max(x, na.rm = TRUE) == min(x, na.rm = TRUE)) return(rep(0, length(x)))
  (x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
}
clean$age_scaled <- scale_minmax(clean$age)
clean$fare_scaled <- scale_minmax(clean$fare)

# 9. Encode categorical variables using one-hot/dummy encoding.
# model.matrix creates numeric indicator columns; exclude response and IDs/text fields.
encoded <- model.matrix(~ sex + pclass + embarked + class + who - 1, data = clean)
encoded_data <- cbind(
  survived = clean$survived,
  age_scaled = clean$age_scaled,
  fare_scaled = clean$fare_scaled,
  sibsp = clean$sibsp,
  parch = clean$parch,
  encoded
)
head(encoded_data)

# 10. Exploratory data analysis
summary(clean)
table(clean$survived)
round(prop.table(table(clean$survived)) * 100, 2)
round(prop.table(table(clean$pclass, clean$survived), 1) * 100, 2)
aggregate(age ~ survived, data = clean, FUN = mean)
aggregate(fare ~ survived, data = clean, FUN = mean)

# Correlation among numeric variables only
numeric_data <- clean %>% select(age, sibsp, parch, fare)
cor_matrix <- cor(numeric_data, use = "complete.obs")
print(round(cor_matrix, 2))
corrplot(cor_matrix, method = "color", addCoef.col = "black",
         title = "Correlation matrix", mar = c(0, 0, 2, 0))

# 11. Visualizations
ggplot(clean, aes(x = survived)) +
  geom_bar(fill = "steelblue") +
  labs(title = "Passenger outcome", x = "Survival", y = "Count") +
  theme_minimal()

ggplot(clean, aes(x = pclass, fill = survived)) +
  geom_bar(position = "fill") +
  labs(title = "Survival proportion by passenger class",
       x = "Passenger class", y = "Proportion", fill = "Survived") +
  theme_minimal()

ggplot(clean, aes(x = age)) +
  geom_histogram(binwidth = 5, fill = "skyblue", color = "white") +
  labs(title = "Age distribution after median imputation",
       x = "Age (years)", y = "Count") +
  theme_minimal()

ggplot(clean, aes(x = pclass, y = fare)) +
  geom_boxplot(fill = "wheat") +
  labs(title = "Fare distribution by passenger class",
       x = "Passenger class", y = "Fare") +
  theme_minimal()

# 12. Export processed data and outputs
write.csv(clean, "titanic_cleaned.csv", row.names = FALSE)
write.csv(encoded_data, "titanic_encoded.csv", row.names = FALSE)
write.csv(outlier_summary, "outlier_summary.csv", row.names = FALSE)
